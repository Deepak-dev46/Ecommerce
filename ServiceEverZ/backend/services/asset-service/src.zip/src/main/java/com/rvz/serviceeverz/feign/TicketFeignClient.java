package com.rvz.serviceeverz.feign;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
 
@FeignClient(
    name = "ticket-service",
    url  = "${ticket.service.base-url:http://localhost:8086/mock/tickets}"
)
public interface TicketFeignClient {
 
    @GetMapping("/{ticketId}")
    Map<String, Object> getTicketById(@PathVariable("ticketId") Long ticketId);
}
 