package com.rvz.serviceeverz.dto.response;

import java.time.LocalDateTime;
import com.rvz.serviceeverz.enums.MappingStatus;

public class AssetMappingResponse {
	private Long id;
	private String mappingNumber, assetTag, assetName;
	private String spRemarks, managerRemarks;
	private String additionalDetailsRequest, additionalDetailsResponse;
	private Long assetId, ticketId;
	private Long requestedByUserId, assignedBySpId, approvedByManagerId;
	private String requestedByUserName, assignedBySpName, approvedByManagerName;
	private MappingStatus status;
	private LocalDateTime spApprovedAt, managerApprovedAt;
	private LocalDateTime assignedFrom, assignedTo, createdAt;

	public Long getId() {
		return id;
	}

	public void setId(Long v) {
		id = v;
	}

	public String getMappingNumber() {
		return mappingNumber;
	}

	public void setMappingNumber(String v) {
		mappingNumber = v;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long v) {
		assetId = v;
	}

	public String getAssetTag() {
		return assetTag;
	}

	public void setAssetTag(String v) {
		assetTag = v;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String v) {
		assetName = v;
	}

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long v) {
		ticketId = v;
	}

	public Long getRequestedByUserId() {
		return requestedByUserId;
	}

	public void setRequestedByUserId(Long v) {
		requestedByUserId = v;
	}

	public Long getAssignedBySpId() {
		return assignedBySpId;
	}

	public void setAssignedBySpId(Long v) {
		assignedBySpId = v;
	}

	public Long getApprovedByManagerId() {
		return approvedByManagerId;
	}

	public void setApprovedByManagerId(Long v) {
		approvedByManagerId = v;
	}

	public String getRequestedByUserName() {
		return requestedByUserName;
	}

	public void setRequestedByUserName(String v) {
		requestedByUserName = v;
	}

	public String getAssignedBySpName() {
		return assignedBySpName;
	}

	public void setAssignedBySpName(String v) {
		assignedBySpName = v;
	}

	public String getApprovedByManagerName() {
		return approvedByManagerName;
	}

	public void setApprovedByManagerName(String v) {
		approvedByManagerName = v;
	}

	public MappingStatus getStatus() {
		return status;
	}

	public void setStatus(MappingStatus v) {
		status = v;
	}

	public String getSpRemarks() {
		return spRemarks;
	}

	public void setSpRemarks(String v) {
		spRemarks = v;
	}

	public String getManagerRemarks() {
		return managerRemarks;
	}

	public void setManagerRemarks(String v) {
		managerRemarks = v;
	}

	public String getAdditionalDetailsRequest() {
		return additionalDetailsRequest;
	}

	public void setAdditionalDetailsRequest(String v) {
		additionalDetailsRequest = v;
	}

	public String getAdditionalDetailsResponse() {
		return additionalDetailsResponse;
	}

	public void setAdditionalDetailsResponse(String v) {
		additionalDetailsResponse = v;
	}

	public LocalDateTime getSpApprovedAt() {
		return spApprovedAt;
	}

	public void setSpApprovedAt(LocalDateTime v) {
		spApprovedAt = v;
	}

	public LocalDateTime getManagerApprovedAt() {
		return managerApprovedAt;
	}

	public void setManagerApprovedAt(LocalDateTime v) {
		managerApprovedAt = v;
	}

	public LocalDateTime getAssignedFrom() {
		return assignedFrom;
	}

	public void setAssignedFrom(LocalDateTime v) {
		assignedFrom = v;
	}

	public LocalDateTime getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(LocalDateTime v) {
		assignedTo = v;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime v) {
		createdAt = v;
	}
}
