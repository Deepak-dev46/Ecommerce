package com.rvz.serviceeverz.feign;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rvz.serviceeverz.dto.response.ApiResponse;
 
@FeignClient(name = "ums-service", url = "${ums.service.url}")
public interface UserServiceClient {
    @GetMapping("/api/users/{userId}/email")
    ApiResponse<String> getUserEmail(@PathVariable("userId") Long userId);
 
    @GetMapping("/api/users/{userId}/name")
    ApiResponse<String> getUserName(@PathVariable("userId") Long userId);
}
 